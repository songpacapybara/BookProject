package com.jojoldu.book.springboot.web.dto;

import com.jojoldu.book.springboot.domain.posts.posts.Posts;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
public class PostsResponseDto {

        private Long id;
        private String title;
        private String content;
        private String author;

        public PostsResponseDto(Posts entity){
            this.id = entity.getId();
            this.title = entity.getTitle();
            this.content = entity.getContent();
            this.author = entity.getAuthor();
        }
}

@Getter
@NoArgsConstructor
public class PostsUpdateRequestDto{
    private String title;
    private String content;

    @Builder
    public PostsUpdateRequestDto(String title, String content)
    {
        this.title = title;
        this.content = content;

    }
}





